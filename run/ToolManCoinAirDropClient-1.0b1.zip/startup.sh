java -cp .:./ToolManCoinAirDropClient-1.0b1.jar tmc.client.AirDropClient
