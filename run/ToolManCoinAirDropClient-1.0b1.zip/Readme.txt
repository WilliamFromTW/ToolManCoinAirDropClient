1. Install Java 8 

2. Modify client.properties
# replace your wallet info
WALLET=TMC-FPZJ-27JU-6UF2-ASF34
WALLET_PUBLIC_KEY=3c3164bec2d060306780cc0a199999853f7e98fafcffa611e616740dce5a4453

3. Run
Execute AirDropClient.exe
