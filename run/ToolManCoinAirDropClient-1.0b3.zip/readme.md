### StartUp     
1. Modify client.properties     
"WALLET":your wallet address        
"WALLET_PUBLIC_KEY":wallet public key
"EXPLORER_NAME": your web browser "firefox" , "explorer" , or "chrome"

 
2. Execute
AirDropClient.exe
or 
java -Xmx768M -cp .;./ToolManCoinAirDropClient-1.0b3.jar tmc.server.AirDropClient
  
